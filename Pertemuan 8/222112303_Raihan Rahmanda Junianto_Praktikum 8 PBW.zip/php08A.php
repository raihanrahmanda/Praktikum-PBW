<!DOCTYPE html> 
<html lang='en-GB'>
<head>
    <title>Hello World</title>
</head>
<body>
    <h1>Our first PHP script</h1>
    <?php
    $user = "Raihan Rahmanda Junianto";
    print ("<p><b>Hello $user<br>\nHello World!</b></p>\n"); ?>
</body>
</html>